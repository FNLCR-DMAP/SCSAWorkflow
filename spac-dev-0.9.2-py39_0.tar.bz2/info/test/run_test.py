print("import: 'spac'")
import spac

